# Known Engineering Blockers & Technical Debt

This register details all known blockers, infrastructure gaps, and architectural debt requiring your review.

---

## 1. Active Release Blockers

### Blocker B1: Remote Supabase Staging DNS Unresolved (`ENOTFOUND`)
* **Impact**: Blocks Gate 5 (`EmployerWorkspaceSecurity.test.js`), Gate 6 (Full Vitest), and Gates 9–12 (Playwright E2E suites).
* **Observed Symptom**: `TypeError: fetch failed` with `getaddrinfo ENOTFOUND phliezryayjzflvdxskd.supabase.co`.
* **Root Cause**: The staging project `headwayos-secondary` (`phliezryayjzflvdxskd`) in region `ap-northeast-2` cannot be resolved by DNS (likely paused in Supabase dashboard due to inactivity).
* **Action Required**: Parth must inspect the authenticated Supabase dashboard to verify if the project is paused, and unpause/restore it or document replacement requirements.

---

## 2. Technical Nuances & Minor Architectural Debt

### Nuance N1: Supabase Server Cookie Context Warning in Vitest
* **Impact**: Emits stderr log during Vitest runs (`Error reading cookies: cookies was called outside a request scope`).
* **Explanation**: Vitest executes mock API routes in a Node environment where Next.js dynamic request context headers are not present. Handlers gracefully fall back to bearer token inspection.
* **Resolution**: Cosmetic; can be silenced with a test mock wrapper for `next/headers`.

### Nuance N2: Multiple GoTrueClient Browser Context Warnings
* **Impact**: Emits warning `Multiple GoTrueClient instances detected in the same browser context`.
* **Explanation**: Occurs when multiple test suites initialize client instances concurrently under the same local storage key.
* **Resolution**: Consolidate singleton client provider in test setup.

### Nuance N3: Next.js ESLint `<img>` Optimization Warnings
* **Impact**: Gate 7 passes with 3 warnings on `NaiveShell.jsx`, `MarketingFooter.jsx`, and `MarketingNav.jsx`.
* **Explanation**: Static marketing and shell components use native HTML `<img>` elements rather than Next.js `<Image />`.
* **Resolution**: Replace with `<Image />` during UI polish milestone.
