# CareerTWiN -> workBYLiNE Founding Engineer Handover: README FIRST

Welcome, Parth. This handover package constitutes the authoritative technical baseline, architectural blueprint, operational model, and roadmap for the **CareerTWiN** private-pilot build as it transitions toward **workBYLiNE**.

As **Founding Engineer**, you hold full technical decision authority over the codebase, architecture, database schemas, and engineering execution.

---

## 1. Core Operating Principles

1. **Human-Led Decision Infrastructure**: CareerTWiN / workBYLiNE is not an automated screening bot, job board, or autonomous rejection tool. It is the proof and evidence layer between a resume and an interview.
2. **Deterministic Evidence Over Model Hallucination**: Factual claims must anchor to explicit `EvidenceRef` coordinates (document, page, excerpt hash, parser version). Scores and confidence are strictly decoupled.
3. **No Unrequested Live Operations**: The repository is currently **FROZEN** at commit `c6278a7e6864dfb870a944cc18045ae5a12d58ee`. Do not deploy to production or run mutating migrations until the staging environment reconciliation is completed.
4. **Zero-Secret Policy**: No credentials, API keys, or raw candidate PII may ever be committed, logged, or pasted into unapproved AI tools.

---

## 2. Navigating this Handover Package

This package is structured into 10 logical domains:

* **[00_START_HERE/](./)**: Executive orientation, system status, known blockers, and your first 5 actions.
* **[01_PRODUCT_CONTEXT/](../01_PRODUCT_CONTEXT/PRODUCT_OVERVIEW.md)**: Product principles, claim boundaries, feature status matrix, and private-pilot operating model.
* **[02_TECHNICAL_ARCHITECTURE/](../02_TECHNICAL_ARCHITECTURE/SYSTEM_ARCHITECTURE.md)**: Monorepo architecture, component map, data flow, trust boundaries, auth lifecycle, and AI integration.
* **[03_REPOSITORY_AND_DEVELOPMENT/](../03_REPOSITORY_AND_DEVELOPMENT/REPOSITORY_GUIDE.md)**: Development workflows, lint/test commands, 13-gate runner mechanics, and GitHub transfer plan.
* **[04_DATABASE_AND_SECURITY/](../04_DATABASE_AND_SECURITY/SUPABASE_PROJECT_RECONCILIATION.md)**: Supabase project status, RLS tenant isolation, database schemas, and security playbooks.
* **[05_TESTING_AND_EVIDENCE/](../05_TESTING_AND_EVIDENCE/TEST_STRATEGY.md)**: Comprehensive testing pyramid, gate execution results, and immutable candidate audit logs.
* **[06_DEPLOYMENT_AND_OPERATIONS/](../06_DEPLOYMENT_AND_OPERATIONS/ENVIRONMENT_MODEL.md)**: Environment topology, staging recovery playbook, rollback runbooks, and incident handling.
* **[07_ROLE_AUTHORITY_AND_AGREEMENTS/](../07_ROLE_AUTHORITY_AND_AGREEMENTS/PARTH_ROLE_CHARTER.md)**: Role charter, decision authority matrix, provisioning register, contractor terms summary, and equity milestone schedule.
* **[08_TECHNICAL_ROADMAP/](../08_TECHNICAL_ROADMAP/ROADMAP_OVERVIEW.md)**: 10 dependency-driven milestones without artificial calendar deadlines.
* **[09_ACCESS_AND_OPERATIONAL_TEMPLATES/](../09_ACCESS_AND_OPERATIONAL_TEMPLATES/ACCESS_REQUEST_CHECKLIST.md)**: Standard templates for ADRs, migrations, incident reports, deployments, and access.
* **[10_FROZEN_SOURCE_SNAPSHOT/](../10_FROZEN_SOURCE_SNAPSHOT/SOURCE_SNAPSHOT_METADATA.md)**: Git-archived commit snapshot (`careertwin-frozen-source-c6278a7.tar.gz`) with complete SHA-256 manifests.
* **[99_HISTORICAL_REFERENCE/](../99_HISTORICAL_REFERENCE/RECOVERY_AND_EXECUTION_TIMELINE.md)**: Complete chronological records and raw evidence logs from recovery phases R1 through R2E.

---

## 3. Immediate Context & Ground Rules

* **Frozen Codebase Location**: `/Users/darshilparmar/Developer/CareerTWiN-Execution/careertwin-monorepo-clean-583ddd8-20260924T144749Z`
* **Current Staging Blocker**: Staging host `phliezryayjzflvdxskd.supabase.co` fails DNS resolution (`ENOTFOUND`). Your first technical task is to inspect the Supabase dashboard to verify project operational status.
* **No Artificial Deadlines**: Technical milestones are ordered by strict dependency and acceptance criteria, not arbitrary calendar dates.
