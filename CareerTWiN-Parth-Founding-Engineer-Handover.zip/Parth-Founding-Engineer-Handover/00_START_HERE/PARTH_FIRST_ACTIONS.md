# Parth's First Engineering Actions & Authorized Sequence

This checklist outlines the mandatory sequential workflow for Parth Thakkar upon taking operational ownership.

---

## Important Notice on Source Archive vs Private Git Clone

> **REFERENCE SNAPSHOT ONLY**: The archive `10_FROZEN_SOURCE_SNAPSHOT/careertwin-frozen-source-c6278a7.tar.gz` is an immutable, commit-bound reference and disaster-recovery backup. It contains **no `.git` directory**.
> 
> **DO NOT EXECUTE `run_gates.sh` FROM THE EXTRACTED TAR.GZ ARCHIVE**, because the release runner requires active Git history and commit graph metadata to bind commit identities (`TESTED_CODE_COMMIT`, `RUNNER_COMMIT`, etc.).
> 
> All gate execution and development must occur within a **proper private Git clone** containing complete repository history, checked out at the authorized commit: `c6278a7e6864dfb870a944cc18045ae5a12d58ee`.

---

## Authorized Step-by-Step Sequence

### Step 1: Inspect the Authenticated Supabase Dashboard
* Log in to the authenticated Supabase management console.
* Locate project `headwayos-secondary` (Reference: `phliezryayjzflvdxskd`, Region: `ap-northeast-2`).
* Inspect project identity, organization ownership, and operational state.

### Step 2: Confirm Project Identity, Ownership, Region & Status
* Verify project reference is exactly `phliezryayjzflvdxskd` in `ap-northeast-2`.
* Determine whether the project is `ACTIVE`, `PAUSED`, `RESTRICTED`, or `DELETED`.
* Note whether custom domains, SSL certificates, or API gateways are active.

### Step 3: Verify Backups, Migrations, Environment Bindings & Credentials
* Confirm available automated and point-in-time PostgreSQL backup snapshots.
* Verify applied migration versions against `src/careertwin/persistence/` and `supabase/migrations/`.
* Verify that staging API keys (`anon` key, `service_role` key) in your secure vault belong to project `phliezryayjzflvdxskd`.

### Step 4: Produce a Written Reconciliation Report
* Document observed dashboard state, network settings, and proposed actions.
* Do not take mutating or billable actions before review.

### Step 5: Obtain Darshil's Approval
* Present the written reconciliation report to Darshil Parmar.
* **Obtain explicit Founder approval BEFORE unpausing, restoring, replacing, deleting, changing DNS, or taking billable/destructive actions.**

### Step 6: Restore Staging Health Safely
* Following approval, execute the authorized staging health restoration.
* Confirm DNS resolution from your terminal:
  ```bash
  dig +short phliezryayjzflvdxskd.supabase.co
  ```

### Step 7: Verify the Private Git Clone & Configure Secrets
* Clone the repository from the private repository host or use the clean execution worktree.
* Verify checkout at authorized commit `c6278a7e6864dfb870a944cc18045ae5a12d58ee` on branch `antigravity/step4b2-frontend-parity`.
* Configure `apps/web/.env.local` (`chmod 600`) with staging secrets from 1Password.
* Install dependencies cleanly using lockfile:
  ```bash
  cd apps/web
  npm ci
  ```

### Step 8: Execute the 13-Gate Runner Exactly Once
* Run the authoritative acceptance runner under strict fail-closed controls:
  ```bash
  bash apps/web/run_gates.sh
  ```
* Verify that all 13 gates pass green and publish atomic candidate evidence.
