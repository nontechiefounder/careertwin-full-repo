# Legal Agreement Execution Checklist

* [ ] Independent Contractor Agreement (Updated commercial terms).
* [ ] Confidentiality & Intellectual Property Assignment Agreement.
* [ ] Pre-Existing IP Schedule (Signed and attached).
* [ ] Equity Milestone Agreement (Board & Shareholder approved).
* [ ] Security & Data Handling Acknowledgement.
