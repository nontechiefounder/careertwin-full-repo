# Comprehensive Access Provisioning Register

| Service Area | Purpose | Access Level | MFA Enforced | Status |
| :--- | :--- | :--- | :---: | :---: |
| **HeadwayOS GitHub** | Source repository & CI/CD | Admin / Maintainer | Hardware Key | Provisioning |
| **Supabase Staging** | Staging DB & Auth management | Developer / Admin | Authenticator | Provisioning |
| **Supabase Production** | Production DB & Auth | Admin (Read/Write) | Authenticator | Provisioning |
| **Vercel / Hosting** | App deployment & env vars | Admin | Authenticator | Provisioning |
| **1Password Team Vault** | Credential vault | Full Member | Biometric/App | Provisioning |
| **Google Gen AI / Gemini**| Model API access | Developer | Google SSO | Provisioning |
| **Postmark / Email** | Transactional mail delivery | Admin | Authenticator | Provisioning |
| **Cloudflare / DNS** | Domain & routing control | View / Read-only | Hardware Key | Founder Held |
| **Cloud Billing & Costs**| AWS / GCP / Supabase costs | Billing Viewer | Google SSO | Provisioning |
| **Sentry / Monitoring** | Telemetry & error logs | Admin | Authenticator | Provisioning |
