# Open Source & Third-Party Dependency Disclosure Template

All third-party open-source dependencies introduced into the monorepo must be recorded below with verified permissive licenses (MIT, Apache 2.0, BSD):

| Package Name | Version | License | Usage Scope | Reviewed By |
| :--- | :---: | :---: | :--- | :--- |
| Next.js | 16.2.1 | MIT | Web Application Framework | Parth |
| Supabase SSR | 0.5.2 | MIT | Server Auth & SSR Client | Parth |
| Vitest | 4.1.2 | MIT | Test Runner | Parth |
