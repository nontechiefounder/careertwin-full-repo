# Confidential Contractor Terms Summary

> **NOTICE**: This document represents a commercial term summary for internal governance and onboarding clarity. It does not replace or supersede executed legal instruments.

---

## 1. Cash Compensation Structure

* **Total Cash Cap through December 2027**: **₹14,00,000 (Fourteen Lakh Indian Rupees) cumulative**.
* **Breakdown**:
  1. **₹5,00,000**: Already paid and settled for prior engineering contributions.
  2. **₹5,00,000**: Catch-up settlement upon agreement execution.
  3. **Up to ₹4,00,000**: Tied to delivery of approved technical roadmap milestones.
* **Engagement Model**: Outcome-based contribution without fixed weekly timesheets or hourly billing.
