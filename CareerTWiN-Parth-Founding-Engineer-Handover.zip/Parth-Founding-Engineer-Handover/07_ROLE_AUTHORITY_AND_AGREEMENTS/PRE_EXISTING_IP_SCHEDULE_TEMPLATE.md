# Pre-Existing Intellectual Property Schedule Template

*DRAFT — COUNSEL REVIEW REQUIRED*

Please list below any pre-existing software tools, libraries, scripts, templates, or intellectual property owned by Parth Thakkar prior to engagement inception (18 November 2025) that will be excluded from company IP assignment:

| # | Item Description | Inception Date | Permitted License to Company |
| :---: | :--- | :---: | :--- |
| 1 | *[e.g. Personal utility scripts]* | *[Date]* | Non-exclusive, royalty-free |
| 2 | *[None / To be populated by Parth]* | | |
