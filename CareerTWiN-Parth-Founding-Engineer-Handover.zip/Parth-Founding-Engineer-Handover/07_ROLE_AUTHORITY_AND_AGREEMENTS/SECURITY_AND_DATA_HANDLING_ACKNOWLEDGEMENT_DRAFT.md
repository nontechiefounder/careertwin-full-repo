# Security & Data Handling Acknowledgement (DRAFT)

*DRAFT — COUNSEL REVIEW REQUIRED*

I, **Parth Thakkar**, in my capacity as **Founding Engineer**, acknowledge and agree to adhere strictly to the following security, privacy, and intellectual property obligations:

1. **Candidate PII Protection**: I will treat all candidate documents as confidential and will not export, share, or store candidate records on unencrypted devices or personal cloud drives.
2. **Zero-Secret Commits**: I will never commit credentials, API keys, or private environment variables to version control.
3. **AI Tool Safety**: I will ensure no confidential company IP, secret keys, or real candidate data is pasted into unapproved public AI tools.
4. **Immediate Incident Disclosure**: I will immediately notify Darshil Parmar of any suspected credential exposure or security anomaly.

---
**Acknowledged**: ___________________________  
**Date**: ___________________________
