# Technical Decision Authority Matrix

| Decision Domain | Parth Authority | Darshil Approval Required? | Notes |
| :--- | :---: | :---: | :--- |
| **Architecture & Frameworks**| Autonomous | No (unless new vendor/DB) | Document ADR for major shifts |
| **Database Migrations** | Autonomous | Yes for Prod Deploys | Must follow expand-and-contract |
| **PR Merging & Reviews** | Autonomous | No | Requires 1 technical review |
| **Staging Deployment** | Autonomous | No | Green gates required |
| **Production Deployment** | Autonomous | **YES** | Dual sign-off required |
| **Incident Rollback / Stop** | **Autonomous** | No (Notify immediately)| Immediate containment authority |
| **Infrastructure Spending** | **Up to ₹4,000 / month** | **YES above ₹4,000/mo** | Fast operational flexibility |
| **DNS & Domain Mutations** | Recommendation | **YES** | Founder approval required |
| **User-Facing Scope Cut** | Recommendation | **YES** | Founder approval required |
| **New Vendor / Cloud Tool** | Recommendation | **YES** | Requires cost & lock-in analysis |
