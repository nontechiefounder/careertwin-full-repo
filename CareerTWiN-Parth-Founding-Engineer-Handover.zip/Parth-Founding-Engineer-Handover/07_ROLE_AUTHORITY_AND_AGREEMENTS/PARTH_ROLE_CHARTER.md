# Founding Engineer Role Charter: Parth Thakkar

## 1. Position & Engagement

* **Name**: Parth Thakkar
* **Title**: Founding Engineer
* **Engagement Type**: Independent Contractor
* **Primary Reporting Line**: Darshil Parmar (Founder)
* **Technical Management Responsibility**: Dhaval Kasundra
* **Public Disclosure**: Not authorized at this time (internal confidential engagement)
* **Investor Data-Room Disclosure**: Not required at this time

---

## 2. Core Responsibilities

1. Lead overall engineering architecture, codebase evolution, and release management.
2. Oversee database schema migrations, multi-tenant RLS enforcement, and security hardening.
3. Manage CI/CD automation, quality gates, and production deployment reliability.
4. Collaborate with Darshil on product roadmap feasibility and design partner pilot deliveries.
