# Confidential Equity Terms & Milestone Schedule

> **NOTICE**: This summary records commercial intent and milestone allocations. Final issuance is subject to definitive agreements, board/shareholder approval, and formal legal execution.

---

## 1. Equity Allocation & Vesting Parameters

* **Maximum Equity Pool**: **Up to 3.00% (Three Percent)** common equity.
* **Vesting Duration**: **36 Months** with time service and milestone satisfaction.
* **Prior Service Credit**: **Six (6) Months** recognized based on contribution inception dating to **18 November 2025**.
* **Cliff Period**: **18 Months** measured from the credited commencement date.
* **Transfer Restrictions**: Standard right of first refusal and founder transfer restrictions apply.

---

## 2. Milestone Equity Allocation Table

| Milestone | Milestone Deliverable Scope | Maximum Equity |
| :---: | :--- | :---: |
| **M1** | CareerTWiN V2 passes all 13 authorized release gates green | **0.50%** |
| **M2** | Secure staging and production environments fully deployed | **0.50%** |
| **M3** | First design-partner private pilot successfully completed | **0.50%** |
| **M4** | Immutable Trust Packet and evidence extraction workflow finalized | **0.75%** |
| **M5** | CI/CD automation, monitoring, rollback, and incident runbooks active | **0.50%** |
| **M6** | Six (6) months of sustained post-handover technical contribution | **0.25%** |
| **Total** | | **3.00%** |
