# Production & Staging Rollback Playbook

## 1. Application Rollback
If a critical error is detected post-deployment:
1. Revert to previous deployment snapshot in hosting platform dashboard (e.g. Vercel instant rollback).
2. Verify HTTP 200 response on health probe.

## 2. Database Rollback
1. Execute matching down-migration:
   ```bash
   alembic downgrade -1
   ```
2. Verify table integrity and RLS policy continuity.
