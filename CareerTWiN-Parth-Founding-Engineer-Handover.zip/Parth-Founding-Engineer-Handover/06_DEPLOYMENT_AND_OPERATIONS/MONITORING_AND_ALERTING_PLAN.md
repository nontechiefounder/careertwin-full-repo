# Monitoring, Telemetry & Alerting Plan

* **Application Metrics**: OpenTelemetry spans for API routes, parser latency, and LLM token consumption.
* **Database Metrics**: Supabase connection pool utilization, query performance, and RLS evaluation times.
* **Error Tracking**: Real-time error capture and alerting integrated with Slack / Discord alerts.
* **Uptime Monitoring**: Synthetic health probes polling `/api/health` every 60 seconds.
