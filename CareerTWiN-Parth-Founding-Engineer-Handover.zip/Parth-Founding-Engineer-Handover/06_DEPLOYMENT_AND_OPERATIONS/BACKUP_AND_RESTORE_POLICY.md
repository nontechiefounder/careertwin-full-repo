# Backup & Disaster Recovery Policy

* **Automated Daily Backups**: Managed PostgreSQL physical backups retained for 30 days.
* **Pre-Migration Point-in-Time Snapshots**: Required before any schema migration.
* **Restoration Testing**: Parth conducts quarterly restoration validation in an isolated staging environment.
