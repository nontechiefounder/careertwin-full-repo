# Environment Topology & Isolation Model

## 1. Environments

1. **Local Development**: Local Next.js dev server on `http://localhost:3000` connected to local or staging Supabase instance with mock email sender.
2. **Staging Environment**: Hosted Supabase instance (`headwayos-secondary` / `phliezryayjzflvdxskd`) in `ap-northeast-2` with `CAREERTWIN_DRY_RUN_EMAIL=true`. Used exclusively for automated CI/CD and pre-release acceptance.
3. **Production Environment**: Isolated production Supabase instance and Vercel/container deployment. Real candidate data permitted **ONLY** after formal acceptance.

---

## 2. Environment Variable Segregation

* Each environment maintains separate, non-overlapping API keys and service-role secrets.
* Production secrets are never accessible from local development machines.
