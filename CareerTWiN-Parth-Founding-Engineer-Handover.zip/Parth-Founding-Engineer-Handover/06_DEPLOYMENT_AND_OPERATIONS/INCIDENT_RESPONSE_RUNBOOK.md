# Incident Response Runbook & Escalation Pathways

## 1. Escalation Contacts

* **Lead Technical Incident Commander**: Parth Thakkar
* **Executive & Governance Lead**: Darshil Parmar
* **Technical Reviewer**: Saneel

## 2. Post-Incident Review
Within 48 hours of resolving any P0/P1 incident, Parth will author a structured incident post-mortem documenting root cause, impact duration, and preventative action items.
