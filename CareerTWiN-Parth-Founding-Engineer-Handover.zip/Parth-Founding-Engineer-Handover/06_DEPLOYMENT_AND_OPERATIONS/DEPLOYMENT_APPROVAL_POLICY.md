# Deployment Governance & Approval Policy

* **Staging Deployments**: Parth holds authority to trigger staging deployments upon successful PR review.
* **Production Deployments**: Require dual authorization:
  1. Technical release certification by **Parth Thakkar (Founding Engineer)**.
  2. Final release sign-off by **Darshil Parmar (Founder)**.
