# Production Readiness & Go-Live Checklist

* [ ] Full 13-gate acceptance suite passes with exit code `0`.
* [ ] Database migrations applied and verified in staging.
* [ ] Production RLS policies audited for zero cross-tenant leakage.
* [ ] DNS records and SSL certificates configured on primary domain.
* [ ] Transactional email provider verified (SPF/DKIM/DMARC configured).
* [ ] Sentry / OpenTelemetry error monitoring active.
* [ ] Formal release approval signed by Darshil.
