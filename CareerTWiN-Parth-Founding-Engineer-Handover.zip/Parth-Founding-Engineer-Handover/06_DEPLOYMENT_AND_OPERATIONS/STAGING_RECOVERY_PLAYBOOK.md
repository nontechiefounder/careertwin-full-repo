# Staging Recovery & Reactivation Playbook

## 1. Authorized Recovery Sequence

1. **Dashboard Inspection**: Log in to authenticated Supabase dashboard.
2. **Identity & Region Verification**: Confirm project `headwayos-secondary` (`phliezryayjzflvdxskd`, `ap-northeast-2`).
3. **Backup & Schema Audit**: Verify PostgreSQL backup availability and migration versions.
4. **Written Reconciliation Report**: Detail status and recommended action.
5. **Founder Approval**: Obtain Darshil's explicit approval before taking unpause, restore, or replacement action.
6. **Safe Restoration**: Perform approved restoration; verify `dig +short phliezryayjzflvdxskd.supabase.co`.
7. **Git Clone Verification**: Ensure clean Git clone at commit `c6278a7e6864dfb870a944cc18045ae5a12d58ee`; execute `npm ci`.
8. **Gate Execution**: Run `bash apps/web/run_gates.sh` exactly once.
