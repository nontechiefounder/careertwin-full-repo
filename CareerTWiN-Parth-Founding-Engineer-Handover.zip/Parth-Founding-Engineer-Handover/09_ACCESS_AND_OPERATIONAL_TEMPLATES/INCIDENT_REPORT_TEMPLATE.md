# Security & Outage Incident Post-Mortem Template

* **Incident Title**: `[Brief summary]`
* **Severity**: P0 / P1 / P2
* **Date & Time of Detection**: `YYYY-MM-DDTHH:MM:SSZ`
* **Duration of Impact**: `XX minutes`
* **Root Cause Analysis (5 Whys)**:
  1.
  2.
  3.
* **Immediate Containment Action**:
* **Preventative Action Items**:
