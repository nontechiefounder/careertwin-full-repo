# Credential Rotation Register Template

| Credential Name | Service | Rotation Reason | Scheduled Date | Rotated By | Verified Green |
| :--- | :--- | :--- | :---: | :---: | :---: |
| `SUPABASE_SERVICE_ROLE_KEY` | Staging | Scheduled Periodic | YYYY-MM-DD | Parth | [ ] |
| `GEMINI_API_KEY` | Google AI | Security Hardening | YYYY-MM-DD | Parth | [ ] |
