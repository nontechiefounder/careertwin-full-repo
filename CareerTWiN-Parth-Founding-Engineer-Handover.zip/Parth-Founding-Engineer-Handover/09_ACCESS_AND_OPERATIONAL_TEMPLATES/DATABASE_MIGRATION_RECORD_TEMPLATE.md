# Database Migration Record Template

* **Migration Revision ID**: `____________________`
* **Description**: `________________________________________`
* **Expand Phase SQL**:
  ```sql
  -- Add new column as nullable
  ```
* **Contract Phase SQL**:
  ```sql
  -- Remove deprecated column
  ```
* **Rollback Tested**: YES / NO
* **Reviewed By**: Parth Thakkar
