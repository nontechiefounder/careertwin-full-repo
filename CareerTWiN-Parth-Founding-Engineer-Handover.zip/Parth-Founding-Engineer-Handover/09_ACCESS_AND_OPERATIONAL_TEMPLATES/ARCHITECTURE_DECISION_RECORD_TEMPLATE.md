# Architecture Decision Record (ADR) Template: ADR-XXXX

## Context & Problem Statement
*[Describe the engineering context, trade-offs, and technical challenges]*

## Considered Options
1. *[Option A]*
2. *[Option B]*

## Decision Outcome
Chosen Option: *[Option A]*, because *[rationale]*.

## Consequences & Security Impact
* **Positive**: *[Benefits]*
* **Negative / Risks**: *[Trade-offs]*
* **Security & Tenant Isolation**: *[Impact]*
