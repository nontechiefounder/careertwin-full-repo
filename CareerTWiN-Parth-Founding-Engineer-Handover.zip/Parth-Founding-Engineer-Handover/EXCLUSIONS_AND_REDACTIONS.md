# Package Exclusions & Redactions Record

This document records all intentional exclusions, security redactions, and sanitized items across the handover package.

## 1. Excluded Items

* **`.git/` Internal Objects**: Excluded from source snapshots to prevent metadata bloat. The source is provided as an immutable git archive.
* **`.env` and `.env.local` Files**: Excluded from package and source archive to enforce the zero-secret policy.
* **Raw Candidate Resumes & PII**: Zero unredacted candidate resumes or PII are included.
* **`node_modules/` & Build Caches**: Excluded to ensure a clean, lightweight, reproducible bundle.

## 2. Redacted Values

* Secret API keys (`SUPABASE_SERVICE_ROLE_KEY`, `GEMINI_API_KEY`, etc.) are referenced strictly by variable name and presence status.
* Personal phone numbers and banking credentials are excluded.
