# CareerTWiN to workBYLiNE Transition Context

## 1. Strategic Rationale

CareerTWiN began as an individual candidate proof engine (a "digital twin" of a candidate's verified career experience). Through customer discovery and early private pilots, the core value proposition evolved into **b2b hiring decision infrastructure for engineering leadership and founders**.

The new brand **workBYLiNE** reflects this mission: every engineering decision and project outcome carries a "byline" of verifiable proof.

---

## 2. Transition Rules & Phasing

To maintain technical stability, the Founder has mandated strict phased sequencing:

1. **Phase 1 (Current)**: **Stabilize CareerTWiN Private-Pilot V2**.
   * Reconcile Supabase staging.
   * Pass all 13 quality gates.
   * Deliver the first 3 design partner proof audits under the existing CareerTWiN architecture.
2. **Phase 2 (Milestone 10)**: **Execute the workBYLiNE Migration**.
   * Multi-tenant domain migration.
   * UI / brand styling refresh.
   * Public launch and commercial expansion.

**Rule**: Do not perform speculative rebrand refactoring, mass file renames, or package name changes until CareerTWiN V2 is stabilized and verified green.
