# CareerTWiN & workBYLiNE Product Overview

## 1. Product Vision

**CareerTWiN** is the existing private-pilot technical foundation transitioning into **workBYLiNE**.

**workBYLiNE** is AI-native hiring decision infrastructure that converts fragmented candidate evidence, historical hiring outcomes, and technical artifacts into auditable, human-led hiring decisions.

CareerTWiN sits directly between a candidate's resume and a high-stakes technical interview. It replaces heuristic screening and unstructured phone screens with a verifiable proof layer.

---

## 2. Core Problem Solved

Modern technical hiring is broken by two symmetric failure modes:
1. **Resume Inflation & AI-Generated Noise**: Candidates submit LLM-polished resumes that exaggerate experience, obscuring authentic skills.
2. **Brittle Keyword Filtering & Ghosting**: Companies use heuristic ATS parsers that discard qualified, unconventional candidates and create legal compliance risks.

CareerTWiN / workBYLiNE extracts **verifiable evidence** (code repositories, architecture decisions, incident post-mortems, verified project outcomes) and matches them deterministically against an approved **Role Requirement Map** (Proof Contract).

---

## 3. Human-in-the-Loop Decision Boundary

CareerTWiN **does not make hiring or rejection decisions**.

* **The Engine's Role**: Extract facts, verify source provenance, identify missing proof signals, calculate requirement matches, and highlight interview probes.
* **The Human's Role**: Review the candidate Trust Packet, evaluate context and trade-offs, conduct targeted evidence-based interviews, and make the final human hiring decision.
