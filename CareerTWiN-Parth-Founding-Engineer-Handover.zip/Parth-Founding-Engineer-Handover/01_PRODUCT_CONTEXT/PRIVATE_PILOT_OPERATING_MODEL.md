# Private-Pilot Operating Model: Proof-Based Shortlist Audit

## 1. The Pilot Offer

* **Offer Name**: **Proof-Based Shortlist Audit**
* **Target Turnaround**: **48 Hours** for eligible candidate cohorts (20–50 candidates per role).
* **Design Partner Terms**: The first **three (3) qualified design partners** participate without charge in exchange for structured feedback and hiring outcome validation. Subsequent audits utilize approved commercial pricing.

---

## 2. Standard Pilot Workflow

```text
[Step 1: Role Intake & Brief]
Hiring Manager inputs Job Description -> CareerTWiN AI generates atomic Requirement Map -> Manager approves Proof Contract.

[Step 2: Candidate Cohort Ingestion]
Manager uploads 20-50 candidate document sets (PDF/DOCX) -> Malware scanned (ClamAV) -> Parsed via Docling.

[Step 3: Evidence Linking & Proof Audit]
Deterministic Engine extracts EvidenceRefs -> Decouples Score & Confidence -> Highlights Missing Proof & Risks.

[Step 4: Trust Packet Generation & Human Shortlist Review]
Engine generates immutable candidate Trust Packets -> Hiring Manager reviews Proof-Ranked Shortlist -> Human selects interview candidates.

[Step 5: Outcome & Interview Probes Delivery]
System provides evidence-linked technical interview probes -> Feedback recorded for future Outcome Learning Loop.
```
