# Comprehensive Feature Status & Audit Matrix

This matrix maps all 26+ functional areas of the CareerTWiN / workBYLiNE platform across implementation state, evidence location, limitations, and pilot suitability.

| Feature Area | Current Status | Implementation & Evidence Location | Dependencies | Known Limitations | Pilot Suitability | Automation Level |
| :--- | :--- | :--- | :--- | :--- | :---: | :---: |
| **Employer Auth** | Implemented (V2) | `apps/web/lib/supabaseServer.js`, `__tests__/security/` | Supabase GoTrue | Blocked on DNS resolution | Ready once unpaused | Fully Automated |
| **Employer Workspace**| Implemented (V2) | `apps/web/app/employer/`, `EmployerWorkspaceSecurity.test.js` | Auth context | Next.js dynamic context in tests | Ready | Fully Automated |
| **Role Creation & Intake** | Implemented (V2) | `apps/web/app/employer/brief/`, `RoleIntakeUI.test.jsx` | Next.js API | Static brief templates | Ready | Semi-Automated |
| **AI Role Brief** | Implemented (V2) | `apps/web/app/api/employer/brief/` | Gemini SDK | Model rate limits | Ready | Semi-Automated |
| **Hiring Genome Snapshot** | Implemented (V2) | `packages/ontology/0.1.0/ontology.yaml` | Ontology package | Static v0.1.0 ontology | Ready | Deterministic |
| **Proof Contract** | Implemented (V2) | `apps/web/__tests__/day4/ProofContractReadiness.test.js` | DB Schema | Requires human approval | Ready | Human-in-the-Loop |
| **Candidate Sourcing**| Implemented (V2) | `apps/web/app/employer/sourcing-session/` | DB Schema | Session limits | Ready | Semi-Automated |
| **Candidate Ingestion**| Implemented (V2) | `apps/web/app/api/candidate/`, `CandidateIngestion.test.js` | MinIO / ClamAV | PDF / DOCX only | Ready | Fully Automated |
| **Docling Parsing** | Backend Engine | `src/careertwin/domain/parsing/` | Docling local | Local CPU compute requirements | Ready | Fully Automated |
| **Claim Ledger** | Implemented (V2) | `src/careertwin/domain/claims/`, `packages/ontology/` | Relational DB | Strict EvidenceRef enforcement | Ready | Deterministic |
| **Evidence Provenance**| Implemented (V2) | `src/careertwin/domain/evidence/` | DB schema | Excerpt hash validation | Ready | Deterministic |
| **Missing Proof Signals** | Implemented (V2) | `apps/web/lib/proofContract.js` | Claim ledger | Signals verify evidence, not reject | Ready | Deterministic |
| **Min Sufficient Proof** | Implemented (V2) | `packages/ontology/0.1.0/rubric.yaml` | Rubric pure fn | Strict gate evaluation | Ready | Deterministic |
| **Trust Packet Gen** | Implemented (V2) | `apps/web/app/employer/packets/`, `CandidateTrustPacketUI.test.jsx`| React / PDF render | Immutable release snapshots | Ready | Fully Automated |
| **Shortlist Workflow** | Implemented (V2) | `apps/web/app/employer/shortlist/`, `CandidateShortlistUI.test.jsx`| BFF API | Bounded shortlist display | Ready | Semi-Automated |
| **Human Review Gates**| Implemented (V2) | `apps/web/app/employer/` | DB Audit log | Mandatory manager approval | Ready | Human-Led |
| **Tenant Isolation & RLS** | Implemented (V2) | `apps/web/__tests__/security/TenantEvidenceSecurity.test.js` | Supabase RLS | Strict `org_id` enforcement | Ready | Fully Automated |
| **Email Safety Controls** | Implemented (V2) | `apps/web/lib/email.js`, `dryRunEmail.test.js` | Mock Mailer | `CAREERTWIN_DRY_RUN_EMAIL=true` | Ready | Enforced |
| **13-Gate Runner** | Implemented (V2) | `apps/web/run_gates.sh` | Bash / Node / Py | Halts on Gate 5 DNS error | Ready | Fully Automated |
| **Audit Trails** | Implemented (V2) | `activity_events` DB table | Postgres | Append-only event logs | Ready | Fully Automated |
| **Outcome Learning Loop** | Architecture/ADR | `docs/adr/0002-postgres-evidence-graph.md` | Postgres DB | Reserved for post-pilot | Roadmap | Planned |
| **Career Proof Diagnostic**| Prototype (V1) | Live MVP V1 | V1 codebase | Candidate-facing diagnostic | Private Pilot | Semi-Automated |
| **Proof Passport** | Architecture | `docs/` | V2 DB | Portable candidate credential | Roadmap | Planned |
| **ATS Integrations** | Explicitly Prohibited | External integration boundary | N/A | Manual CSV/PDF import only for MVP | Out of Scope | None |
| **B2B Subscriptions** | Roadmap | Stripe billing | Stripe API | Planned for commercial launch | Roadmap | Planned |
| **workBYLiNE Migration**| Roadmap | `08_TECHNICAL_ROADMAP/MILESTONE_10` | Full monorepo | Scheduled after V2 stabilization | Roadmap | Planned |
