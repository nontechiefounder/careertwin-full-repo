# Product Principles & Claim Boundaries

To ensure legal compliance, algorithmic fairness, and technical integrity, all engineering and product development must strictly observe the following boundaries.

---

## 1. Mandatory Domain Invariants

1. **Approved Role Requirements**: Requirements must be atomic, job-related, versioned, and explicitly approved by a human hiring manager before candidate scoring begins.
2. **Evidence-Anchored Claims**: Every supported `Claim` and `RequirementMatch` must reference at least one valid `EvidenceRef` containing document coordinates, bounding box/page offset, excerpt hash, and parser version.
3. **Decoupled Score & Confidence**: Score (degree of qualification match) and Confidence (evidence reliability) are separate numerical values. High confidence in weak evidence never inflates a candidate's score.
4. **Deterministic Eligibility Gates**: Must-have constraints and disqualifiers are calculated in pure, deterministic code—never delegated to model discretion.
5. **Immutable Released Trust Packets**: Released Trust Packets are immutable. Any correction or re-evaluation generates a new versioned snapshot.
6. **Audited Human Overrides**: Any reviewer override requires actor identity, timestamp, previous value, new value, and documented reason.

---

## 2. Prohibited Scoring Features

The following features must **NEVER** be extracted, stored, or utilized for scoring, ranking, or filtering candidates:
* Name, photograph, gender, or sexual orientation.
* Age, date of birth, or graduation year.
* Race, ethnicity, religion, or nationality.
* Disability, medical condition, or pregnancy status.
* Address, zip code, or neighborhood.
* Marital or parental status.
* Historical employee similarity matching (which perpetuates historical bias).

---

## 3. Marketing & Commercial Claim Boundaries

When documenting or discussing product capabilities, adhere to these truth boundaries:
* ❌ **DO NOT CLAIM**: "Autonomous AI hiring" or "Instant candidate rejection".
* ❌ **DO NOT CLAIM**: "Universal candidate score" (scoring is role-specific).
* ❌ **DO NOT CLAIM**: "Guaranteed bias elimination" or "Unconditional 48-hour SLA".
* ✅ **DO CLAIM**: "Auditable human-in-the-loop decision infrastructure".
* ✅ **DO CLAIM**: "48-hour target turnaround for eligible private-pilot candidate sets".
