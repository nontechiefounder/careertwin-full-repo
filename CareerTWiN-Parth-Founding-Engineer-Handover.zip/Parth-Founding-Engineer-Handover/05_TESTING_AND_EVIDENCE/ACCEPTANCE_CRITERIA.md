# Definition of Done for V2 Release Acceptance

A release candidate is accepted **ONLY** when all of the following conditions are met:
1. All 13 quality gates in `apps/web/run_gates.sh` exit with code `0`.
2. Staging Supabase instance is active and passes real authenticated browser UAT.
3. Working tree contains zero uncommitted modifications.
4. Zero security or RLS test regressions.
5. Atomic candidate log is published with valid double-hash verification.
6. Formal release sign-off provided by Founder (Darshil).
