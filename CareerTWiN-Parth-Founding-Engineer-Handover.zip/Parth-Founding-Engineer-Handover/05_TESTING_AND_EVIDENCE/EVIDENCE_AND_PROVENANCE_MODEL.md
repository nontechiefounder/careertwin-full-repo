# Evidence & Provenance Data Model

## 1. Cryptographic Immutability

* Every raw document uploaded generates a canonical SHA-256 digest upon ingestion.
* Every parsed text chunk preserves exact character start/end offsets and parser version.
* Candidate Trust Packets compile these claims into an immutable JSON document hashed with SHA-256 before human release.

---

## 2. Verification Guarantees

* If a source document is modified or deleted, the packet version retains the cryptographic excerpt hash.
* Reviewers can click any score component in the UI to view the exact highlighted bounding box in the original document.
