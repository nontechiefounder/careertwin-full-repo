# Quality Assurance & Testing Strategy

## 1. Testing Pyramid

```text
        /  Playwright E2E Suites (Gates 9-12)  \
       /----------------------------------------\
      /    Vitest Security & Auth (Gates 2-5)    \
     /--------------------------------------------\
    /  Vitest Discovery & Pure Unit Tests (Gate 6)  \
   /------------------------------------------------\
  /     Alembic Schema & Core Pure Fns (Make Verify)  \
```

---

## 2. Test Execution Levels

1. **Fast Local Core Verification**: `make verify-core` (runs fast pure domain checks).
2. **Component & Route Unit Tests**: `npx vitest run` (executes 41 discovered test suites).
3. **Automated Release Runner**: `bash apps/web/run_gates.sh` (executes the 13 sequential release gates).
