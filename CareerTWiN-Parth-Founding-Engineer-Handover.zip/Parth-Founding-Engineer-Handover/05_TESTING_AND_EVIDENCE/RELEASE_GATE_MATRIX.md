# 13 Quality Gates Definition Matrix

| Gate # | Gate Name | Command / Tool | Success Standard |
| :---: | :--- | :--- | :--- |
| **Pre** | Staging Environment Check | Shell assertion in `run_gates.sh` | Required env vars present; non-prod target |
| **1** | ProofContractReadiness Vitest | `npx vitest run ProofContractReadiness.test.js` | 100% tests pass (10 tests) |
| **2** | SourcingSessionSecurity Vitest | `npx vitest run SourcingSessionSecurity.test.js` | 100% tests pass (10 tests) |
| **3** | HiringRunSecurity Vitest | `npx vitest run HiringRunSecurity.test.js` | 100% tests pass (25 tests) |
| **4** | ShortlistSecurity Vitest | `npx vitest run ShortlistSecurity.test.js` | 100% tests pass (5 tests) |
| **5** | EmployerWorkspaceSecurity Vitest | `npx vitest run EmployerWorkspaceSecurity.test.js` | 100% tests pass (17 tests) |
| **6** | Full Discovered Vitest Suite | `npx vitest run` | All 41 suites pass |
| **7** | Directory-Scoped ESLint Audit | `npx eslint ...` | 0 errors |
| **8** | Next.js Production Build | `npm run build` | Clean production build compiled |
| **9** | Day 4 Playwright UAT Assertions | `npx playwright test EmployerDay4Assertions...` | Browser E2E flows pass |
| **10** | Day 3 Playwright Regression | `npx playwright test EmployerDay3Assertions...` | Regression assertions pass |
| **11** | Employer Chat Playwright | `npx playwright test EmployerChatAssertions...` | Chat interactions pass |
| **12** | Candidate Trust Packet Playwright | `npx playwright test CandidateTrustPacket...` | Packet rendering passes |
| **13** | Executable Integrity & Cleanup | Shell assertion in `run_gates.sh` | Port 3000 free; log published |
