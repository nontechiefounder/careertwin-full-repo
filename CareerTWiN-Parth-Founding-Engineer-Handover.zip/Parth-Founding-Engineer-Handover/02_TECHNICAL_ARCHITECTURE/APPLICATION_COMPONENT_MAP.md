# Application Component & Route Topology

## 1. Frontend Workspace Topology (`apps/web`)

* **`/app/employer/`**: Employer workspace root, role management, and analytics dashboard.
* **`/app/employer/brief/[id]/`**: Role intake, requirement drafting, and Proof Contract approval UI.
* **`/app/employer/sourcing-session/[id]/`**: Candidate cohort upload, processing status, and progress indicator.
* **`/app/employer/shortlist/[roleId]/`**: Proof-ranked candidate shortlist with evidence drilldowns.
* **`/app/employer/packets/[extractionId]/`**: Candidate Trust Packet review, evidence drawer, and interview probe generator.
* **`/app/candidate/`**: Candidate proof profile and diagnostic views.

---

## 2. API Route Handlers (`apps/web/app/api/`)

* **`/api/employer/brief/`**: Role brief generation and update endpoints.
* **`/api/employer/hiring-runs/`**: Hiring run creation, status queries, and requirement mapping.
* **`/api/employer/sourcing-sessions/`**: Ingestion session orchestration and upload completion.
* **`/api/employer/packets/`**: Trust packet release, reviewer action recording, and PDF export.
* **`/api/candidate/proof-profile/`**: Candidate profile retrieval and diagnostic summaries.

---

## 3. Backend Engine Packages (`packages/*` & `src/careertwin/*`)

* **`packages/ontology/0.1.0/`**: Authoritative domain ontology (`ontology.yaml`) and scoring rubric (`rubric.yaml`).
* **`src/careertwin/domain/`**: Pure domain functions for evidence linking, eligibility gating, and score calculation.
* **`src/careertwin/persistence/`**: SQLAlchemy models, PostgreSQL RLS session context managers, and Alembic migrations.
* **`src/careertwin/orchestration/`**: Deterministic state machine managing pipeline advancement.
