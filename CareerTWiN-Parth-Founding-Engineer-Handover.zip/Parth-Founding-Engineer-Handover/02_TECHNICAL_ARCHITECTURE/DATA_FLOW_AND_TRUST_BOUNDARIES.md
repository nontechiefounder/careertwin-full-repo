# Data Flow & Trust Boundaries

## 1. Untrusted Input Handling

All candidate-uploaded files (PDFs, DOCX) and employer inputs are treated as **hostile, untrusted data**.

```text
[Upload Intent Created]
       |
       v
[Quarantine S3 Bucket] ---> [ClamAV Malware Scan]
                                   |
                     +-------------+-------------+
                     |                           |
                 [Malware]                   [Clean]
                     |                           |
                     v                           v
              [Quarantine Alert]          [Docling Parser Isolation]
              [Execution Halted]                 |
                                                 v
                                          [Text Extraction]
                                                 |
                                                 v
                                      [Evidence Graph Linking]
```

---

## 2. Security Boundaries

* **No LLM Shell Access**: Model extraction adapters have zero access to shells, databases, networks, or file systems.
* **Tenant Isolation**: Every database operation is bound to a verified `org_id` enforced both at the application layer and by PostgreSQL RLS.
* **Prompt Injection Defense**: Resumes are passed to LLMs strictly inside structured schema extraction boundaries with explicit instruction delimiter guards.
