# Proof Engine Architecture & Provenance Model

## 1. The Evidence Provenance Model (`EvidenceRef`)

Every factual assertion within the system is encapsulated in an immutable `EvidenceRef`:

```typescript
interface EvidenceRef {
  documentId: string;        // UUID of source document in tenant storage
  documentSha256: string;    // SHA-256 of original untampered file
  pageNumber: number;        // 1-indexed page location
  boundingBox?: [number, number, number, number]; // [x0, y0, x1, y1] normalized
  excerpt: string;           // Exact text excerpt extracted
  excerptSha256: string;     // SHA-256 hash of extracted excerpt
  parserVersion: string;     // e.g. "docling-v2.1.0"
  extractedAt: string;       // ISO-8601 timestamp
}
```

---

## 2. Pure Scoring Function

Final candidate scoring is a pure, deterministic function of matched claims:

$$	ext{Final Score} = \sum_{r \in 	ext{Requirements}} w_r \cdot 	ext{MatchStrength}(r, 	ext{Claims}_r) \cdot 	ext{GateMultiplier}(r)$$

* If a must-have requirement evaluates to `UNMET`, $	ext{GateMultiplier} = 0$.
* Model confidence values **never** increment or multiply the score.
