# System Architecture & Component Topology

## 1. High-Level Architecture Diagram

```text
+-----------------------------------------------------------------------------------+
|                                 USER BROWSER / CLIENT                             |
|  (Next.js 16 App Router UI - Employer Workspace, Shortlist, Candidate Packet)      |
+------------------------------------------+----------------------------------------+
                                           | HTTPS / JSON (BFF API Routes)
                                           v
+-----------------------------------------------------------------------------------+
|                            NEXT.JS BACKEND-FOR-FRONTEND                           |
|  - Route Handlers (/app/api/*)                                                    |
|  - Server-Side GoTrue Auth & Cookie Management                                    |
|  - Dry-Run Email Safety Enforcement                                               |
+---------------------+---------------------------------------+---------------------+
                      |                                       |
       Postgres / RLS |                        gRPC / REST /  | Document Offsets /
       Direct Access  |                        Celery Tasks   | JSON Contracts
                      v                                       v
+---------------------+-------------+   +---------------------+---------------------+
|      SUPABASE POSTGRESQL + RLS    |   |           PYTHON BACKEND ENGINE           |
|  - 13 Public Core Tables          |   |  - FastAPI Engine Contracts               |
|  - Multi-Tenant Row Level Security|   |  - Docling Local Document Parser          |
|  - Transactional app.current_org  |   |  - Pure Scoring & Rubric Pure Functions   |
|  - pgvector Evidence Embeddings   |   |  - Bounded Gemini SDK AI Adapter          |
+-----------------------------------+   +-------------------------------------------+
```

---

## 2. Core Architectural Decisions (ADRs)

1. **ADR 0001: Backend-First Monorepo**: All business logic, scoring gates, and evidence graphs reside in versioned, strict backend contracts. UI is a thin projection layer.
2. **ADR 0002: PostgreSQL Evidence Graph**: Relational edges with `EvidenceRef` provenance inside PostgreSQL rather than a separate, unversioned graph database.
3. **ADR 0003: Explicit Orchestration**: Deterministic stage progression (`VALIDATING -> PARSING -> ROLE_REVIEW -> EXTRACTING -> LINKING -> SCORING -> PACKET_DRAFT -> HUMAN_REVIEW -> RELEASED`) without unconstrained autonomous agent loops.
