# AI Provider Integrations & Schema Validation

## 1. Provider & Routing

* **Primary Provider**: Google Gemini via official Google Gen AI SDK (`@google/genai`).
* **Configuration**: `GEMINI_STORE_INTERACTIONS=false` enforced to prevent training on customer data.
* **Secrets**: `GEMINI_API_KEY` is loaded strictly from process environment and never logged.

---

## 2. Bounded Structured Extraction

LLM interactions are strictly restricted to schema-constrained JSON transformations:
1. **Role Brief Generation**: Input raw JD -> Output validated `RoleRequirementMap` schema.
2. **Claim Extraction**: Input parsed document chunks -> Output structured `Claim[]` array with source offsets.
3. **Interview Probe Generation**: Input missing proof signals -> Output targeted behavioral/technical interview questions.
