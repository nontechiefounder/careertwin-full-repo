# Authentication, Session Lifecycle & GoTrue Integration

## 1. Authentication Architecture

* **Provider**: Supabase GoTrue authentication engine.
* **Session Transport**: HTTP-only, secure cookies with JWT bearer tokens.
* **Server Verification**: Handled by `apps/web/lib/supabaseServer.js` using authenticated Supabase client initialization.

---

## 2. Decommissioning of Mock Sessions

In earlier development checkpoints (Step 4B3), synthetic mock sessions were used. Under **Step 4B5.4-R2** and **UX-V2-D4-C1**, mock sessions were completely decommissioned:

* Deprecated mock session tokens immediately return `401 DEPRECATED_SESSION`.
* All routes enforce authentic GoTrue session validation.
* Zero synthetic mock data is accepted in production route handlers.
