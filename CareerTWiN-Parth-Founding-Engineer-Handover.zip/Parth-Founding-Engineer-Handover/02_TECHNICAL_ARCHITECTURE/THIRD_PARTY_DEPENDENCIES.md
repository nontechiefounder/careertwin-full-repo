# Third-Party Dependencies & Bill of Materials

## 1. Web Application (`apps/web`)

* **Next.js**: `16.2.1` (Turbopack, App Router)
* **React**: `19.0.0`
* **@supabase/supabase-js**: `2.100.1`
* **@supabase/ssr**: `0.5.2`
* **Vitest**: `4.1.2`
* **Playwright**: `1.50.0`
* **ESLint**: `9.x`
* **TailwindCSS**: `3.4.x`

---

## 2. Backend Engine (`python`)

* **Python**: `3.12+`
* **FastAPI**: `0.115+`
* **Pydantic**: `v2.10+`
* **SQLAlchemy**: `2.0+`
* **Alembic**: `1.14+`
* **Docling**: Local document parsing engine
* **psycopg3**: PostgreSQL driver
* **OpenTelemetry**: Vendor-neutral tracing and metrics
