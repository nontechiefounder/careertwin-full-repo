# CareerTWiN Frozen Source Snapshot Metadata

## 1. Snapshot Identity

* **Archive Filename:** `careertwin-frozen-source-c6278a7.tar.gz`
* **Source Repository:** `/Users/darshilparmar/Developer/CareerTWiN-Execution/careertwin-monorepo-clean-583ddd8-20260924T144749Z`
* **Frozen Branch:** `antigravity/step4b2-frontend-parity`
* **Frozen Commit SHA:** `c6278a7e6864dfb870a944cc18045ae5a12d58ee`
* **Commit Subject:** `fix(runner): add staging env preflight checks and first-failure halt enforcement`
* **Creation Timestamp (UTC):** `2026-09-25T00:11:00Z`
* **Archive Format:** `tar.gz` (gzip compressed tar archive generated via `git archive`)
* **Archive SHA-256:** `a76baa9eccda1a4a1856f4df089937a775eaa341c0035aa76fc77f5114f95f14`
* **Root Prefix:** `careertwin-monorepo-c6278a7/`

---

## 2. Archive Content Statistics

* **Total Archive Entries:** `921` (directories + regular files)
* **Regular Tracked Files:** `702`
* **Internal Git Metadata (`.git`):** **ABSENT (0 bytes)**
* **Local Environment Files (`.env*`):** **ABSENT (0 bytes)**
* **Node Modules (`node_modules/`):** **ABSENT (0 bytes)**
* **Build Artifacts (`.next/`, caches):** **ABSENT (0 bytes)**
* **OS Metadata (`.DS_Store`):** **ABSENT (0 bytes)**

---

## 3. Verification & Extraction Instructions

To verify and extract this source snapshot in a clean location:

```bash
# Verify checksum
shasum -a 256 careertwin-frozen-source-c6278a7.tar.gz
# Expected: a76baa9eccda1a4a1856f4df089937a775eaa341c0035aa76fc77f5114f95f14

# Test archive integrity without extraction
tar -tzf careertwin-frozen-source-c6278a7.tar.gz > /dev/null

# Extract into target folder
mkdir -p careertwin-monorepo
tar -xzf careertwin-frozen-source-c6278a7.tar.gz -C careertwin-monorepo --strip-components=1
```

Individual file hashes are listed in `SOURCE_FILE_MANIFEST.sha256`.
