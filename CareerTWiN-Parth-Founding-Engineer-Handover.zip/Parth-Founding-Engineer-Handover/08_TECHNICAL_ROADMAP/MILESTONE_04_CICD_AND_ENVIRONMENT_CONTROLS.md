# Milestone 04: CI/CD Automation & Environment Controls

* **Objective**: Transfer repository to HeadwayOS GitHub organization, configure GitHub Actions CI pipeline, and enforce branch protections.
* **Dependencies**: Milestone 03 complete.
* **Acceptance Criteria**:
  1. GitHub Actions automatically executes Vitest and build on all pull requests.
  2. Branch protection rules prevent direct pushes to `main`.
