# Milestone 02: Supabase Staging Reconciliation & Reactivation

* **Objective**: Complete the authorized 8-stage Supabase dashboard inspection, verify project identity, obtain Founder approval, restore staging health, and verify DNS reachability.
* **Dependencies**: Milestone 01 complete; Supabase dashboard access provisioned.
* **Workstream**:
  1. Authenticated dashboard inspection of `headwayos-secondary` (`phliezryayjzflvdxskd`, `ap-northeast-2`).
  2. Backup and migration audit.
  3. Written reconciliation report delivery.
  4. Founder approval sign-off.
  5. Staging health reactivation.
* **Acceptance Criteria**:
  1. Staging project operational in `ap-northeast-2`.
  2. `dig +short phliezryayjzflvdxskd.supabase.co` resolves to active host IP.
  3. `apps/web/.env.local` verified against active staging instance.
