# Database Migration & Schema Evolution Policy

## 1. Expand-and-Contract Migration Pattern

To ensure zero-downtime releases, all schema migrations must follow the expand-and-contract pattern:
1. **Expand**: Add new columns or tables as nullable or with defaults.
2. **Migrate**: Transition application code to read/write new structures.
3. **Contract**: Remove legacy columns or constraints in a subsequent release.

---

## 2. Migration Guidelines

* Every schema modification requires an explicit, versioned Alembic / SQL migration file.
* Never modify an already-applied migration revision in place.
* Always test both forward migration (`upgrade head`) and rollback (`downgrade -1`).
