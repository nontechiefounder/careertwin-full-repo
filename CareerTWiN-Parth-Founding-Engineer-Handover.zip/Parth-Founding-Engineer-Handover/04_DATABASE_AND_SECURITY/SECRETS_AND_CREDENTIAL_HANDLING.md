# Secrets & Credential Handling Policy

## 1. Strict Zero-Secret Commit Rule

* **NEVER** commit `.env`, `.env.local`, API keys, private keys, or passwords to Git.
* `git check-ignore` must confirm all `.env` files are ignored before commit.
* Secret values must never be output to stdout/stderr in logs or test runners.

---

## 2. Staging & Production Key Storage

* All shared credentials must be stored in the company 1Password vault.
* Access is granted individually with mandatory MFA.
* Credential rotation must follow the standard rotation runbook.
