# Row Level Security (RLS) & Tenant Isolation

## 1. Two-Layer Tenant Isolation

CareerTWiN enforces tenant isolation at two independent layers:
1. **Application Layer**: Application handlers verify `org_id` from authenticated GoTrue JWT claims before constructing database queries.
2. **Database Layer (PostgreSQL RLS)**: Every table enforces strict RLS policies checking `app.current_org_id` inside the database transaction.

---

## 2. Example RLS Policy Structure

```sql
-- Enforce organization membership isolation
CREATE POLICY tenant_isolation_policy ON hiring_runs
  FOR ALL
  TO authenticated
  USING (org_id = current_setting('app.current_org_id', true)::uuid);
```
