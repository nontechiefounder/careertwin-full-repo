# Security Incident Response Process

## 1. Incident Severity Tiers

* **P0 (Critical)**: Active cross-tenant data leak, exposed service-role key, or unauthorized database access.
* **P1 (High)**: Staging environment exposure, failed RLS policy, or unauthenticated API access.
* **P2 (Medium)**: Secret committed to private branch, misconfigured CORS, or dependency vulnerability.

---

## 2. Immediate Containment Authority

Parth holds the authority to:
1. Immediately rotate compromised credentials.
2. Terminate running production/staging server instances.
3. Revoke active user sessions in Supabase GoTrue.
4. Notify Darshil within 30 minutes of incident confirmation.
