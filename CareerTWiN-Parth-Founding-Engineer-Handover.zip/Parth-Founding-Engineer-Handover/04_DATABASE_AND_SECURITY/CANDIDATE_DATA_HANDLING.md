# Candidate Data Handling & Privacy Safeguards

## 1. Data Classification

* **Public**: Marketing copy, public ontology definitions.
* **Confidential**: Role briefs, Proof Contracts, aggregated statistics.
* **Strictly Confidential / PII**: Candidate resumes, contact information, extracted claims.

---

## 2. Handling Controls for Engineering

* Access candidate data only on encrypted, approved development hardware.
* Never export candidate data to personal cloud drives, WhatsApp, or unapproved tools.
* Delete temporary parsing artifacts and test files once testing is complete.
* Never input real candidate resumes into commercial LLM web interfaces (e.g. ChatGPT web).
