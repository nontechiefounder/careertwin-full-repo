# Engineering Security Access Checklist

* [ ] Individual GitHub account configured with mandatory hardware MFA.
* [ ] Individual Supabase dashboard account assigned with RBAC.
* [ ] 1Password team vault access provisioned.
* [ ] Local development machine disk encryption (FileVault) verified active.
* [ ] Git commit signing with GPG/SSH key enabled.
* [ ] Signed Security & Data Handling Acknowledgement on file.
