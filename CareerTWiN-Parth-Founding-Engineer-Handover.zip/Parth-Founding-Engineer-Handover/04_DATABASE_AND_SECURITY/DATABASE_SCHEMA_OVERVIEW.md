# Database Schema & Entity Relationship Overview

## 1. Core 13 Application Tables

1. `organizations`: Tenant entities and enterprise account definitions.
2. `organization_memberships`: User-to-organization RBAC relationships (`owner`, `recruiter`, `auditor`).
3. `profiles`: User account metadata linked to Supabase `auth.users`.
4. `hiring_runs`: High-level role evaluation runs and job intake instances.
5. `candidates`: Candidate entities linked to tenant organizations.
6. `candidate_profiles`: Structured candidate experience and skill metadata.
7. `proof_profiles`: Versioned proof and evidence evaluation records.
8. `sourcing_sessions`: Candidate cohort ingestion and batch processing sessions.
9. `screening_sessions`: Interactive candidate screening workflows.
10. `screening_answers`: Granular candidate responses and question assessments.
11. `screening_summaries`: Aggregated screening diagnostic outputs.
12. `activity_events`: Append-only audit trail recording every reviewer action.
13. `scheduled_emails`: Queue for transactional emails (dry-run enforced).
