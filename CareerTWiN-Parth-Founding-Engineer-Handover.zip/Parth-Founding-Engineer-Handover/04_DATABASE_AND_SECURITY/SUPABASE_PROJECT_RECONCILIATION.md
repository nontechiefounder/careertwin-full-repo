# Supabase Project Reconciliation & Staging Diagnostic

## 1. Canonical Staging Resolution

* **Canonical Project Name**: `headwayos-secondary`
* **Canonical Project Reference**: `phliezryayjzflvdxskd`
* **Region**: `ap-northeast-2` (Seoul)
* **Observed Condition**: DNS Unresolved (`ENOTFOUND phliezryayjzflvdxskd.supabase.co`).
* **Operational State**: Unconfirmed pending authenticated dashboard inspection.

---

## 2. Project Reference Reconciliation Table

| Attribute | `phliezryayjzflvdxskd` (Canonical) | `feevwepkmudqomtxlyda` (Typo) |
| :--- | :--- | :--- |
| **History in Codebase**| Documented in Step 4B5.2, Step 4B5.4-R2, `.env.staging`, and `apps/web/.env.local` | Zero occurrences in codebase, migrations, or git commits |
| **Status** | Canonical staging reference | Erroneous report table entry from R2B diagnostic |
| **Action** | Reconcile via dashboard sequence below | Discard / Ignore |

---

## 3. Mandatory 8-Stage Staging Reconciliation Sequence

All staging reconciliation must proceed through this exact 8-stage sequence:

1. **Inspect Authenticated Dashboard**: Log in to Supabase management console.
2. **Confirm Project Identity**: Verify project name `headwayos-secondary`, reference `phliezryayjzflvdxskd`, region `ap-northeast-2`, and status.
3. **Verify Configuration Integrity**: Audit backups, migrations, environment bindings, and credential ownership without printing secret keys.
4. **Produce Written Reconciliation Report**: Document findings and proposed technical remediation.
5. **Obtain Darshil Approval**: Require Founder sign-off before unpausing, restoring, replacing, deleting, modifying DNS, or incurring billable changes.
6. **Restore Staging Health Safely**: Execute approved restoration and verify DNS resolution (`dig +short phliezryayjzflvdxskd.supabase.co`).
7. **Verify Git Clone Baseline**: Ensure working in a clean private Git clone at commit `c6278a7e6864dfb870a944cc18045ae5a12d58ee` with `npm ci` dependencies.
8. **Execute 13-Gate Runner**: Run `bash apps/web/run_gates.sh` exactly once under fail-closed controls.
