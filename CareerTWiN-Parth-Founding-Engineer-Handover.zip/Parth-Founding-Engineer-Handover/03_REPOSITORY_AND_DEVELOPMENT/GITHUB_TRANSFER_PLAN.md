# HeadwayOS GitHub Organization Transfer Plan

## 1. Destination Repository

* **Organization**: HeadwayOS GitHub Organization
* **Repository Name**: `careertwin-monorepo` (later transitioning to `workbyline`)
* **Visibility**: Private

---

## 2. Step-by-Step Transfer Sequence

1. **Create Repository**: Darshil creates private repo `headwayos/careertwin-monorepo`.
2. **Assign Parth as Admin**: Grant Parth repository administrator permissions using his individually verified GitHub account.
3. **Push Clean Frozen Baseline**:
   ```bash
   git remote add origin git@github.com:headwayos/careertwin-monorepo.git
   git push -u origin antigravity/step4b2-frontend-parity
   git push origin --tags
   ```
4. **Configure Branch Protections**:
   * Require PR reviews before merging.
   * Require status checks to pass before merging.
   * Require signed commits.
   * Prohibit force pushes and deletions on `main`.
