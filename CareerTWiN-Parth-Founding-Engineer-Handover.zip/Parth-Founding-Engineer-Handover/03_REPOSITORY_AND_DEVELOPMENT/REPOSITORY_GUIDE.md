# Monorepo Structure & Development Guide

## 1. Directory Layout

```text
careertwin-monorepo/
├── apps/
│   └── web/                    # Next.js 16 Web Application (App Router BFF)
│       ├── app/                # Route handlers and React Server Components
│       ├── components/         # Reusable UI component library
│       ├── lib/                # Shared clients (Supabase, email, auth)
│       ├── __tests__/          # Vitest unit & Playwright E2E suites
│       └── run_gates.sh        # Authoritative 13-gate release test runner
├── packages/
│   └── ontology/               # Versioned domain ontology & scoring rubrics
│       └── 0.1.0/              # Released v0.1.0 definitions (YAML)
├── src/
│   └── careertwin/             # Python backend domain, persistence & workers
│       ├── domain/             # Pure domain logic (scoring, parsing, claims)
│       ├── persistence/        # SQLAlchemy models & migrations
│       └── orchestration/      # Explicit state machine workflows
├── infra/                      # Docker Compose & local development definitions
├── docs/                       # Architectural Decision Records (ADRs) & specs
└── Makefile                    # Core verification targets
```

---

## 2. Core Rules of the Repository

1. **Backend-First**: Place domain logic in `src/careertwin/domain/`, not in ad-hoc React components.
2. **Never Commit Secrets**: Local environment configuration resides strictly in git-ignored `.env.local` files.
3. **Deterministic Changes**: Changes to scoring, ontology, or gates require matching unit tests and ADR updates.
