# Branching & Pull Request Policy

## 1. Branch Naming Conventions

* `feat/<feature-name>`: New feature implementations
* `fix/<bug-description>`: Bug fixes and runner repairs
* `sec/<security-patch>`: Security hardening and RLS adjustments
* `docs/<topic>`: Architectural documentation and ADRs
* `refactor/<scope>`: Non-behavioral code restructuring

---

## 2. Pull Request Standards

* **Direct pushes to `main` are strictly prohibited.**
* Every PR must include:
  1. Clear summary of changes and affected boundaries.
  2. Test results from `bash apps/web/run_gates.sh` or targeted Vitest suites.
  3. Security & tenant isolation impact statement.
  4. At least one technical review approval (Parth or Saneel) + Darshil's sign-off.
