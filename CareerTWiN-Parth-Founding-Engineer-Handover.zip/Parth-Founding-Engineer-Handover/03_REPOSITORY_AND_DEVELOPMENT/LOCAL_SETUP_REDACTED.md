# Local Development Environment Setup (Redacted)

## 1. Prerequisites

* **Node.js**: `v20.x` or `v22.x` (LTS recommended)
* **Python**: `3.12+` with `uv` package manager installed
* **Docker & Docker Compose**: For local PostgreSQL/MinIO development services
* **Git**: `2.40+`

---

## 2. Step-by-Step Installation

### Step A: Extract Source Archive
```bash
mkdir -p ~/Developer/CareerTWiN-Local
tar -xzf 10_FROZEN_SOURCE_SNAPSHOT/careertwin-frozen-source-c6278a7.tar.gz -C ~/Developer/CareerTWiN-Local --strip-components=1
cd ~/Developer/CareerTWiN-Local
```

### Step B: Install Web Dependencies
```bash
cd apps/web
npm install
```

### Step C: Configure Local Secrets Safely
Create `apps/web/.env.local` and set restrictive permissions (`chmod 600`):
```bash
touch apps/web/.env.local
chmod 600 apps/web/.env.local
```
Populate the required variable keys from your secure 1Password vault:
* `NEXT_PUBLIC_SUPABASE_URL`
* `NEXT_PUBLIC_SUPABASE_ANON_KEY`
* `SUPABASE_SERVICE_ROLE_KEY`
* `CAREERTWIN_STAGING_TEST_PASSWORD`
* `CAREERTWIN_DRY_RUN_EMAIL=true`

### Step D: Run Development Server
```bash
npm run dev
# Starts local development server on http://localhost:3000
```
