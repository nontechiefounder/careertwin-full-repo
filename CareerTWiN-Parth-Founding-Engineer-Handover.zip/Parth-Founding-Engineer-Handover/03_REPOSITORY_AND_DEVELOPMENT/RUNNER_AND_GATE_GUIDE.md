# Gate Runner Architecture & Mechanics (`run_gates.sh`)

## 1. Overview

`apps/web/run_gates.sh` is the authoritative, fail-closed acceptance runner for CareerTWiN V2.

---

## 2. Key Architectural Features

1. **Atomic Single-Run Lock**: Enforces a `/tmp/UX-V2-D4-C1-runner.lock` directory mutex containing owner PID to prevent race conditions.
2. **Pre-Flight Staging Assertion**: Verifies that required staging variables (`NEXT_PUBLIC_SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `CAREERTWIN_STAGING_TEST_PASSWORD`, `CAREERTWIN_DRY_RUN_EMAIL`) are present and valid before Gate 1 runs. Redacts all secret values in logs.
3. **Commit Identity Binding**: Separately binds `TESTED_CODE_COMMIT`, `RUNNER_COMMIT`, `BUILD_COMMIT`, and `SERVER_SOURCE_COMMIT`.
4. **Immediate First-Failure Halt**: If any gate (1 through 12) exits non-zero, the runner immediately halts, kills running process trees, verifies port 3000 is free, releases the lock, and publishes atomic diagnostic evidence.
5. **Atomic Evidence Publication**: Generates an immutable `.log` file in `apps/web/Files/` verified with double byte-count and SHA-256 validation.
