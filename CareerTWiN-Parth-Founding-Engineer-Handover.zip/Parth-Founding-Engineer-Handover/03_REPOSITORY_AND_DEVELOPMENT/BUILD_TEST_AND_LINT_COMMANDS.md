# Build, Test & Lint Command Reference

## 1. Web Application (`apps/web`)

```bash
# Run all discovered unit and security Vitest suites
npm test

# Run a specific Vitest suite
npx vitest run __tests__/security/RunnerIdentityContract.test.js

# Run directory-scoped ESLint audit
npx eslint app/employer "app/employer/brief/[id]/page.jsx" app/api/employer components lib __tests__/day4 __tests__/day3 __tests__/chat __tests__/packet __tests__/security

# Run clean Next.js production build
npm run build

# Run Playwright end-to-end tests (requires running Next.js server on port 3000)
npx playwright test __tests__/day4/EmployerDay4Assertions.test.js --workers=1
```

---

## 2. Full 13-Gate Acceptance Runner

```bash
# Execute the complete, atomic, fail-closed release runner
bash apps/web/run_gates.sh
```
