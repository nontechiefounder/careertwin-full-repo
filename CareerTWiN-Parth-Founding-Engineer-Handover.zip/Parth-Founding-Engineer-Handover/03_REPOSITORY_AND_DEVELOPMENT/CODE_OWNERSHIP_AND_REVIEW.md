# Code Ownership & Review Governance

## 1. Ownership & Roles

* **Parth Thakkar (Founding Engineer)**: Repository Administrator, Lead Technical Reviewer, Release Manager.
* **Saneel (Engineering Reviewer)**: Technical Architecture & Security Reviewer.
* **Darshil Parmar (Founder)**: Product Direction, Scope Approvals, Final Release Sign-off.

---

## 2. Review Routing Matrix

| Change Type | Primary Reviewer | Required Approvals |
| :--- | :--- | :--- |
| **Frontend UI / Components** | Parth | 1 Approval (Parth or Saneel) |
| **Backend API Route Handlers** | Parth | 1 Approval (Parth) |
| **Database Schema & Migrations**| Parth | 2 Approvals (Parth + Darshil) |
| **Security & Auth Changes** | Parth | 2 Approvals (Parth + Saneel) |
| **Production Release Deployment**| Parth | 2 Approvals (Parth + Darshil) |
