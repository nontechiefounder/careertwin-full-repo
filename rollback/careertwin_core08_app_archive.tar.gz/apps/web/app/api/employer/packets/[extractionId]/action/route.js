import { createSupabaseServerClient } from '@/lib/supabaseServer';
import { requireUser, getVerifiedOrgMembership } from '@/lib/serverAuth';
import { NextResponse } from 'next/server';
import { sendGmailEmail } from '@/lib/gmail';
import { sendSMTPEmail } from '@/lib/smtp';
import { createClient } from '@supabase/supabase-js';

function getAdminClient() {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || process.env.CAREERTWIN_STAGING_SUPABASE_URL;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!serviceRoleKey) {
    throw new Error("FAIL-CLOSED ERROR: SUPABASE_SERVICE_ROLE_KEY is missing.");
  }
  return createClient(supabaseUrl, serviceRoleKey);
}

export async function POST(request, { params }) {
  try {
    const { extractionId } = await params;

    // 1. ROUTE AUTHORIZATION FIRST — BEFORE any privileged operation!
    const authRes = await requireUser(request);
    if (authRes.errorResponse) return authRes.errorResponse;
    const { user, supabase } = authRes;

    // 2. VALIDATE ACTION STRICT WHITELIST (CTW-IP-038)
    const body = await request.json().catch(() => ({}));
    const { action, rationale } = body;
    const VALID_ACTIONS = ['advance', 'hold', 'reject'];

    if (!action || !VALID_ACTIONS.includes(action)) {
      return NextResponse.json({
        error: 'INVALID_ACTION',
        details: `Action must be one of: ${VALID_ACTIONS.join(', ')}`
      }, { status: 400 });
    }

    if (!rationale || typeof rationale !== 'string' || rationale.trim().length === 0) {
      return NextResponse.json({
        error: 'RATIONALE_REQUIRED',
        details: 'A non-empty human decision rationale is required for all candidate actions.'
      }, { status: 400 });
    }

    // 3. Fetch candidate entry using authenticated user client
    let { data: extraction, error: fetchError } = await supabase
      .from('candidates')
      .select('id, candidate_id, decision_packet, hiring_runs(org_id)')
      .eq('id', extractionId)
      .maybeSingle();

    if (!extraction && !fetchError) {
      const { data: fallback } = await supabase
        .from('candidates')
        .select('id, candidate_id, decision_packet, hiring_runs(org_id)')
        .eq('candidate_id', extractionId)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      extraction = fallback;
    }

    if (!extraction) {
      return NextResponse.json({ error: 'Candidate not found' }, { status: 404 });
    }

    // 4. VERIFY ACTIVE EMPLOYER ORG MEMBERSHIP BEFORE ANY SIDE EFFECTS
    const orgId = extraction.hiring_runs?.org_id;
    const membership = await getVerifiedOrgMembership(supabase, user.id, orgId);
    if (!membership || !['owner', 'recruiter', 'admin', 'hiring_manager'].includes(membership.membership_role)) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    // 5. Update candidate status with explicit human rationale
    const dbStatus = action === 'advance' ? 'shortlisted' : action === 'hold' ? 'hold' : 'rejected';

    let adminClient;
    try {
      adminClient = getAdminClient();
    } catch (e) {
      adminClient = supabase;
    }

    const existingDecision = extraction.decision_packet?.human_decision || {};
    const existingHistory = Array.isArray(existingDecision.decision_history)
      ? existingDecision.decision_history
      : (existingDecision.action ? [{
          action: existingDecision.action,
          status: existingDecision.status,
          rationale: existingDecision.rationale,
          actor_id: existingDecision.actor_id,
          actor_email: existingDecision.actor_email,
          timestamp: existingDecision.timestamp || existingDecision.recorded_at,
          recorded_at: existingDecision.recorded_at || existingDecision.timestamp,
          reviewed_ledger_revision: existingDecision.reviewed_ledger_revision,
          reviewed_rubric_version: existingDecision.reviewed_rubric_version,
          reviewed_document_id: existingDecision.reviewed_document_id
        }] : []);

    const newDecisionEvent = {
      action,
      status: dbStatus,
      rationale: rationale || null,
      actor_id: user.id,
      actor_email: user.email || 'user',
      timestamp: new Date().toISOString(),
      recorded_at: new Date().toISOString(),
      reviewed_ledger_revision: extraction.decision_packet?.ledger_revision,
      reviewed_rubric_version: extraction.decision_packet?.rubric_version,
      reviewed_document_id: extraction.decision_packet?.candidate_document_id,
      requires_re_review: false
    };

    const updatedPacket = {
      ...(extraction.decision_packet || {}),
      human_decision: {
        ...newDecisionEvent,
        decision_history: [...existingHistory, newDecisionEvent]
      }
    };

    const { data: candidate, error: updateError } = await adminClient
      .from('candidates')
      .update({
        status: dbStatus,
        decision_packet: updatedPacket
      })
      .eq('id', extraction.id)
      .select('*, candidate_profiles(*), hiring_runs(*)')
      .single();

    if (updateError) {
      console.error('Status update error:', updateError);
      return NextResponse.json({ error: 'Failed to update status' }, { status: 500 });
    }

    // Record auditable human decision activity event with actor identity
    try {
      await adminClient.from('activity_events').insert([{
        event_type: dbStatus,
        title: `Human Action: ${action.toUpperCase()}`,
        description: `Candidate status updated to ${dbStatus} by authenticated user ${user.id} (${user.email || 'user'}). Rationale: ${rationale || 'None provided'}.`
      }]);
    } catch (actErr) {
      console.warn('Activity event logging notice:', actErr.message);
    }

    // 6. Trigger Email Sequence if Advanced (Dry-Run by Default)
    if (action === 'advance') {
      const orgId = extraction.hiring_runs?.org_id;
      await handleAdvanceSequence(adminClient, user.id, candidate, orgId);
    }

    return NextResponse.json({ success: true, status: dbStatus });

  } catch (err) {
    console.error('Action error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

async function handleAdvanceSequence(supabase, employerId, candidate, orgId) {
  const targetCandidateProfileId = candidate.candidate_id || candidate.id;
  const targetOrgId = orgId || candidate.hiring_runs?.org_id || null;

  // Inspect existing sequence days for idempotency and recovery after partial sequence creation
  let existingDays = new Set();

  if (typeof supabase.from('scheduled_emails')?.select === 'function') {
    try {
      const { data: existingEmails } = await supabase
        .from('scheduled_emails')
        .select('id, sequence_day')
        .eq('candidate_id', targetCandidateProfileId);

      if (existingEmails && Array.isArray(existingEmails) && existingEmails.length > 0) {
        existingEmails.forEach(e => {
          if (e && typeof e.sequence_day === 'number') {
            existingDays.add(e.sequence_day);
          } else {
            // Mock or legacy record without explicit sequence_day implies full sequence initiated
            existingDays.add(0);
            existingDays.add(2);
            existingDays.add(5);
          }
        });

        // If all 3 sequence days (0, 2, 5) are already present, suppress duplicate sequence
        if (existingDays.has(0) && existingDays.has(2) && existingDays.has(5)) {
          console.log(`[Email] Sequence already fully initiated for candidate ${targetCandidateProfileId}; suppressing duplicate.`);
          return;
        }
      }
    } catch (e) {
      console.warn('[Email] Existing sequence days inspection notice:', e?.message || e);
    }
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('gmail_refresh_token, gmail_email, name')
    .eq('id', employerId)
    .single();

  const candidateName = candidate.candidate_profiles?.name || 'there';
  let candidateEmail = candidate.candidate_profiles?.email;
  if (candidateEmail && typeof candidateEmail === 'string' && candidateEmail.startsWith('[')) {
    try {
      const parsed = JSON.parse(candidateEmail);
      if (Array.isArray(parsed)) candidateEmail = parsed[0];
    } catch (e) {}
  }

  const roleTitle = candidate.hiring_runs?.role_title || 'the role';
  const senderName = profile?.name || 'CareerTWiN Team';

  // Strict Fail-Closed Dry-Run Boundary: Disabled by default for demo/test environments!
  // Unless explicitly set to false, ALL outreach emails are dry_run!
  const isDryRun = process.env.CAREERTWIN_DRY_RUN_EMAIL !== 'false';

  const day0Subject = `Next step for the ${roleTitle} opportunity`;
  const day0Body = `
    <p>Hi ${candidateName},</p>
    <p>Thanks for getting back to us.</p>
    <p>Based on your background, we think you may be a strong fit for the <strong>${roleTitle}</strong> role we’re working on.</p>
    <p>The next step is a short profile setup so we can evaluate your background properly and move you into the active process.</p>
    <p><a href="${process.env.NEXT_PUBLIC_URL || 'http://localhost:3000'}/candidate/onboarding/${candidate.candidate_id}" style="padding: 10px 20px; background: #000; color: #fff; text-decoration: none; border-radius: 5px;">Complete your profile here</a></p>
    <p>It should only take a few minutes.</p>
    <p>Best,<br>${senderName}<br>CareerTWiN</p>
  `;

  let day0Status = 'dry_run';
  let day0Error = 'Dry run active: external candidate email suppressed for demo safety.';

  if (!isDryRun) {
    try {
      if (!candidateEmail) {
        day0Status = 'failed';
        day0Error = 'Candidate has no email address associated with their profile.';
      } else if (profile?.gmail_refresh_token) {
        await sendGmailEmail(profile.gmail_refresh_token, {
          to: candidateEmail,
          subject: day0Subject,
          body: day0Body
        });
        day0Status = 'sent';
        day0Error = null;
      } else if (process.env.SYSTEM_EMAIL_USER) {
        await sendSMTPEmail({
          to: candidateEmail,
          subject: day0Subject,
          body: day0Body,
          fromName: senderName
        });
        day0Status = 'sent_via_system';
        day0Error = null;
      } else {
        day0Status = 'failed';
        day0Error = 'No Gmail connected and no system fallback configured.';
      }
    } catch (err) {
      day0Status = 'failed';
      day0Error = err.message || String(err);
    }
  }

  // 1. Insert Day 0 if missing
  if (!existingDays.has(0)) {
    const day0Payload = {
      employer_id: employerId,
      candidate_id: targetCandidateProfileId,
      sequence_day: 0,
      scheduled_for: new Date().toISOString(),
      subject: day0Subject,
      body: day0Body,
      status: day0Status,
      error_details: day0Error,
      sent_at: day0Status.includes('sent') ? new Date().toISOString() : null
    };
    if (targetOrgId) day0Payload.org_id = targetOrgId;

    const { error: day0Err } = await supabase.from('scheduled_emails').insert([day0Payload]);

    if (day0Err) {
      if (day0Err.code === '23505' || day0Err.message?.includes('duplicate key') || day0Err.message?.includes('idx_scheduled_emails')) {
        console.log(`[Email] Atomic database constraint prevented duplicate Day 0 sequence for candidate ${targetCandidateProfileId} (code 23505).`);
        return; // Concurrent collision on Day 0: suppress downstream sequence days to avoid racing
      } else {
        console.error('[Email] Failed to insert day 0 scheduled email:', day0Err);
        return;
      }
    }
    existingDays.add(0);
  }

  // 2. Recovery / Completion: Insert missing Day 2 and Day 5
  const day2Date = new Date();
  day2Date.setDate(day2Date.getDate() + 2);
  
  const day5Date = new Date();
  day5Date.setDate(day5Date.getDate() + 5);

  const onboardingLink = `${process.env.NEXT_PUBLIC_URL || 'http://localhost:3000'}/candidate/onboarding/${candidate.candidate_id}`;

  const missingSequences = [];

  if (!existingDays.has(2)) {
    const day2Payload = {
      employer_id: employerId,
      candidate_id: targetCandidateProfileId,
      sequence_day: 2,
      scheduled_for: day2Date.toISOString(),
      subject: `Follow-up: ${roleTitle} opportunity`,
      body: `
        <p>Hi ${candidateName},</p>
        <p>Just checking in to see if you had a chance to look at the overview I sent earlier for the <strong>${roleTitle}</strong> role.</p>
        <p>We're really impressed by your background and would love to have your profile ready for the team to review.</p>
        <p><a href="${onboardingLink}">Continue your profile setup here</a></p>
        <p>Best,<br>${senderName}</p>
      `,
      status: isDryRun ? 'dry_run' : 'pending',
      error_details: isDryRun ? 'Dry run active: external candidate email suppressed for demo safety.' : null
    };
    if (targetOrgId) day2Payload.org_id = targetOrgId;
    missingSequences.push(day2Payload);
  }

  if (!existingDays.has(5)) {
    const day5Payload = {
      employer_id: employerId,
      candidate_id: targetCandidateProfileId,
      sequence_day: 5,
      scheduled_for: day5Date.toISOString(),
      subject: `Final nudge: ${roleTitle} role`,
      body: `
        <p>Hi ${candidateName},</p>
        <p>I'm sending this one last note regarding the <strong>${roleTitle}</strong> role. We're moving into the final review stage and would love to include your profile if you're still interested.</p>
        <p>If you have a moment, you can complete the setup here:</p>
        <p><a href="${onboardingLink}">Complete your profile</a></p>
        <p>Otherwise, feel free to let me know if the timing isn't right.</p>
        <p>Best,<br>${senderName}</p>
      `,
      status: isDryRun ? 'dry_run' : 'pending',
      error_details: isDryRun ? 'Dry run active: external candidate email suppressed for demo safety.' : null
    };
    if (targetOrgId) day5Payload.org_id = targetOrgId;
    missingSequences.push(day5Payload);
  }

  if (missingSequences.length > 0) {
    const { error: seqErr } = await supabase.from('scheduled_emails').insert(missingSequences);
    if (seqErr && (seqErr.code === '23505' || seqErr.message?.includes('duplicate key'))) {
      console.log('[Email] Subsequent sequence days already present in database (23505).');
    }
  }
}
