import { createSupabaseServerClient } from '@/lib/supabaseServer';
import { getVerifiedOrgMembership } from '@/lib/serverAuth';
import { parseDocument } from '@/lib/parser/documentParser';
import { NextResponse } from 'next/server';

export async function POST(request) {
  try {
    const supabase = await createSupabaseServerClient(request);
    const { data: { user }, error: authError } = await supabase.auth.getUser();

    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const formData = await request.formData();
    const file = formData.get('file');
    const hiringRunId = formData.get('hiring_run_id');
    const candidateIdParam = formData.get('candidate_id');
    const candidateNameParam = formData.get('candidate_name') || 'Candidate Applicant';

    if (!file || typeof file === 'string') {
      return NextResponse.json({ error: 'No file uploaded' }, { status: 400 });
    }

    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    // 1. Genuine Parser Execution
    let parseResult;
    try {
      parseResult = await parseDocument({
        buffer,
        filename: file.name || 'document.pdf',
        mimeType: file.type || 'application/pdf'
      });
    } catch (parseErr) {
      console.error('[Document Upload Parse Error]:', parseErr.message);
      return NextResponse.json({
        error: 'PARSER_EXECUTION_FAILURE',
        details: parseErr.message
      }, { status: 422 });
    }

    // 2. Resolve Tenant Organization & Membership
    let orgId = null;
    let hiringRun = null;

    if (hiringRunId) {
      const { data: runData, error: runError } = await supabase
        .from('hiring_runs')
        .select('*')
        .eq('id', hiringRunId)
        .maybeSingle();

      if (!runError && runData) {
        hiringRun = runData;
        orgId = runData.org_id;
      }
    }

    if (!orgId) {
      const { data: memData } = await supabase
        .from('organization_memberships')
        .select('organization_id')
        .eq('user_id', user.id)
        .eq('membership_status', 'active')
        .limit(1)
        .maybeSingle();

      if (memData) orgId = memData.organization_id;
    }

    if (!orgId) {
      return NextResponse.json({ error: 'Organization context not found' }, { status: 403 });
    }

    const membership = await getVerifiedOrgMembership(supabase, user.id, orgId);
    if (!membership || !['owner', 'admin', 'recruiter', 'hiring_manager'].includes(membership.membership_role)) {
      return NextResponse.json({ error: 'Forbidden: Insufficient tenant privileges' }, { status: 403 });
    }

    const supabaseService = await createSupabaseServerClient(request, true);

    // 3. Resolve or Create Candidate Profile
    let candidateProfileId = null;
    let candidateRowId = null;

    if (candidateIdParam) {
      // Check if candidateIdParam is a candidates row ID
      const { data: existingCand } = await supabaseService
        .from('candidates')
        .select('id, candidate_id')
        .eq('id', candidateIdParam)
        .maybeSingle();

      if (existingCand) {
        candidateRowId = existingCand.id;
        candidateProfileId = existingCand.candidate_id;
      } else {
        // Maybe it is a profile ID directly
        const { data: existingProf } = await supabaseService
          .from('candidate_profiles')
          .select('id')
          .eq('id', candidateIdParam)
          .maybeSingle();
        if (existingProf) {
          candidateProfileId = existingProf.id;
        }
      }
    }

    if (!candidateProfileId) {
      const syntheticEmail = `cand.${Date.now()}.${Math.floor(Math.random() * 10000)}@example.invalid`;
      const { data: uData, error: uErr } = await supabaseService.auth.admin.createUser({
        email: syntheticEmail,
        password: 'TestPassword123!',
        email_confirm: true
      });

      if (uErr || !uData?.user) {
        console.error('Error creating auth user for candidate profile:', uErr);
        return NextResponse.json({ error: 'Failed to create candidate auth user' }, { status: 500 });
      }

      const userId = uData.user.id;
      await supabaseService.from('profiles').upsert([{
        id: userId,
        email: syntheticEmail,
        name: candidateNameParam || 'Parsed Candidate',
        role: 'candidate'
      }]);

      const textLines = parseResult.normalized_text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
      const headlineMatch = textLines.find(l =>
        l.length < 80 && /(engineer|developer|architect|lead|manager|specialist|analyst|administrator|consultant|sre)/i.test(l)
      ) || textLines[0]?.substring(0, 50) || 'Infrastructure Engineer';
      const cleanHeadline = headlineMatch.replace(/^[\W_]+|[\W_]+$/g, '').trim();

      const { data: newProfile, error: profError } = await supabaseService
        .from('candidate_profiles')
        .upsert([{
          id: userId,
          email: syntheticEmail,
          name: candidateNameParam || 'Parsed Candidate',
          bio: cleanHeadline || 'Infrastructure Engineer',
          location: 'Parsed from Resume'
        }])
        .select()
        .single();

      if (profError || !newProfile) {
        console.error('Error creating profile for document:', profError);
        return NextResponse.json({ error: 'Failed to create candidate profile' }, { status: 500 });
      }
      candidateProfileId = newProfile.id;
    }

    if (hiringRunId && !candidateRowId) {
      const { data: existingCand } = await supabaseService
        .from('candidates')
        .select('id')
        .eq('hiring_run_id', hiringRunId)
        .eq('candidate_id', candidateProfileId)
        .maybeSingle();

      if (existingCand) {
        candidateRowId = existingCand.id;
      } else {
        const { data: newCand, error: candError } = await supabaseService
          .from('candidates')
          .insert([{
            hiring_run_id: hiringRunId,
            candidate_id: candidateProfileId,
            status: 'new'
          }])
          .select()
          .single();

        if (candError) {
          console.error('Error creating candidate record:', candError);
          return NextResponse.json({ error: 'Failed to create candidate record' }, { status: 500 });
        }
        candidateRowId = newCand.id;
      }
    }

    // 4. Persist Canonical Parsed Document with Real Hashes and Parser Metadata
    const { data: docRecord, error: docError } = await supabaseService
      .from('candidate_documents')
      .insert([{
        candidate_id: candidateProfileId,
        org_id: orgId,
        hiring_run_id: hiringRunId || null,
        filename: parseResult.filename,
        mime_type: parseResult.mime_type,
        byte_size: buffer.length,
        file_sha256: parseResult.file_sha256,
        normalized_text: parseResult.normalized_text,
        normalized_text_sha256: parseResult.normalized_text_sha256,
        parser_name: parseResult.parser_name
      }])
      .select()
      .single();

    if (docError) {
      console.error('Error persisting candidate document:', docError);
      return NextResponse.json({ error: 'Failed to persist candidate document', details: docError }, { status: 500 });
    }

    return NextResponse.json({
      success: true,
      document: docRecord,
      candidate_id: candidateRowId,
      profile_id: candidateProfileId,
      extraction_id: candidateRowId
    });

  } catch (err) {
    console.error('Document upload error:', err);
    return NextResponse.json({ error: 'Internal server error: ' + err.message }, { status: 500 });
  }
}
