"use client";

import { useState } from "react";
import { ArrowLeft, Zap, UploadCloud, Loader2 } from "lucide-react";
import Link from "next/link";
import api from "@/lib/api";
import { toast } from "sonner";

export default function ShortlistHeader({
  roleTitle,
  company,
  roleId,
  counts = {},
  onUploadSuccess
}) {
  const [uploading, setUploading] = useState(false);
  const cohortCandidates = counts.cohort_candidates || 0;
  const evaluationsCompleted = counts.evaluations_completed || 0;
  const pendingEvaluation = Math.max(0, cohortCandidates - evaluationsCompleted);

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    const toastId = toast.loading(`Ingesting & parsing ${file.name} via pdf-parse@2.4.5...`);

    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("hiring_run_id", roleId);
      
      // Derive candidate name from filename (e.g. alex_chen_systems_resume.pdf -> Alex Chen)
      const baseName = file.name.replace(/\.[^/.]+$/, "").replace(/[_-]/g, " ");
      const formattedName = baseName.replace(/\b\w/g, l => l.toUpperCase());
      formData.append("candidate_name", formattedName);

      const res = await api.post("/employer/candidate-documents/upload", formData, {
        headers: { "Content-Type": undefined }
      });

      if (res.data?.success) {
        toast.success(
          `Parsed & ingested ${file.name} successfully via ${res.data.document.parser_name} ✓`,
          { id: toastId }
        );
        if (onUploadSuccess) onUploadSuccess(res.data);
      } else {
        toast.error(res.data?.error || "Upload failed", { id: toastId });
      }
    } catch (err) {
      const msg = err.response?.data?.details || err.response?.data?.error || err.message;
      toast.error(`Ingestion error: ${msg}`, { id: toastId });
    } finally {
      setUploading(false);
      // Reset input
      e.target.value = "";
    }
  };

  return (
    <header className="border-b border-[#343434] bg-[#111111] px-6 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
      <div className="flex items-center gap-3">
        <Link
          href={`/employer/brief/${roleId}`}
          className="p-2 rounded-lg border border-[#343434] bg-[#1A1A1A] text-[#A3A3A3] hover:text-[#F2F2F2] hover:border-[#10D97A]/40 transition-colors"
          aria-label="Return to Role Brief"
        >
          <ArrowLeft className="h-4 w-4" />
        </Link>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-lg font-semibold text-[#F2F2F2] tracking-tight">
              {roleTitle || "Candidate Shortlist"}
            </h1>
            <span
              className="px-2.5 py-0.5 rounded-full border border-[#343434] bg-[#1A1A1A] text-[#F2F2F2] text-[10px] font-mono font-medium"
              data-testid="cohort-candidates-badge"
            >
              {cohortCandidates} Cohort Candidates
            </span>
          </div>
          <p className="text-xs text-[#A3A3A3] mt-0.5 font-mono" data-testid="shortlist-subtitle">
            {company ? `${company} · ` : ""}{evaluationsCompleted} evaluations completed · {pendingEvaluation} pending evaluation
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        <label
          className="px-3 py-1.5 rounded-lg border border-[#10D97A]/40 bg-[#10D97A]/10 text-xs font-medium text-[#10D97A] hover:bg-[#10D97A]/20 transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
          data-testid="upload-resume-btn"
        >
          {uploading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <UploadCloud className="h-3.5 w-3.5" />}
          Upload Candidate Resume
          <input
            type="file"
            accept=".pdf,.docx,.csv"
            disabled={uploading}
            className="hidden"
            data-testid="shortlist-file-upload-input"
            onChange={handleFileUpload}
          />
        </label>

        <Link
          href={`/employer/brief/${roleId}`}
          className="px-3 py-1.5 rounded-lg border border-[#343434] bg-[#1A1A1A] text-xs font-medium text-[#F2F2F2]/80 hover:text-[#F2F2F2] hover:border-[#10D97A]/40 transition-all flex items-center gap-1.5"
        >
          <Zap className="h-3.5 w-3.5 text-[#10D97A]" />
          View Role Brief
        </Link>
      </div>
    </header>
  );
}
